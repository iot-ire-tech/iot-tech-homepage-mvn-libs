package com.stripe.model.issuing;

import com.stripe.model.StripeCollection;

public class DisputeCollection extends StripeCollection<Dispute> {}
