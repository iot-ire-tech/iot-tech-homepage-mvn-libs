package com.stripe.model;

public class InvoiceCollection extends StripeCollection<Invoice> {}
