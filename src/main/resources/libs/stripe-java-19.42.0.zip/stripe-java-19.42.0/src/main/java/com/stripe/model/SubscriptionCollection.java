package com.stripe.model;

public class SubscriptionCollection extends StripeCollection<Subscription> {}
