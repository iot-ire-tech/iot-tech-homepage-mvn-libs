package com.stripe.model;

public class ChargeCollection extends StripeCollection<Charge> {}
