package com.stripe.model;

public class FileLinkCollection extends StripeCollection<FileLink> {}
