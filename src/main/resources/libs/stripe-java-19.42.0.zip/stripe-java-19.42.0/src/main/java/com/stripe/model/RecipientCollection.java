package com.stripe.model;

public class RecipientCollection extends StripeCollection<Recipient> {}
