package com.stripe.model;

public class TaxRateCollection extends StripeCollection<TaxRate> {}
