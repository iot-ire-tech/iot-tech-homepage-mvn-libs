package com.stripe.model;

public class ExchangeRateCollection extends StripeCollection<ExchangeRate> {}
