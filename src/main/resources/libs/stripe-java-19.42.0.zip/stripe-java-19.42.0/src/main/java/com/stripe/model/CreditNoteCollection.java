package com.stripe.model;

public class CreditNoteCollection extends StripeCollection<CreditNote> {}
