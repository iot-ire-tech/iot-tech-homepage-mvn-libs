package com.stripe.model.reporting;

import com.stripe.model.StripeCollection;

public class ReportRunCollection extends StripeCollection<ReportRun> {}
