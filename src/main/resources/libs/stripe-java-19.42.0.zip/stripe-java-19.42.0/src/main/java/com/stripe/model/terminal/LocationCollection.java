package com.stripe.model.terminal;

import com.stripe.model.StripeCollection;

public class LocationCollection extends StripeCollection<Location> {}
