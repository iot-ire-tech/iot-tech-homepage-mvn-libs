package com.stripe.model;

public class BalanceTransactionCollection extends StripeCollection<BalanceTransaction> {}
