package com.stripe.model.terminal;

import com.stripe.model.StripeCollection;

public class ReaderCollection extends StripeCollection<Reader> {}
