package com.stripe.model;

public interface BalanceTransactionSource extends StripeObjectInterface, HasId {}
