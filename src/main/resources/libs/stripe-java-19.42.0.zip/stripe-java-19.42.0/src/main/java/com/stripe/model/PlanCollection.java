package com.stripe.model;

public class PlanCollection extends StripeCollection<Plan> {}
