package com.stripe.model;

public class PromotionCodeCollection extends StripeCollection<PromotionCode> {}
