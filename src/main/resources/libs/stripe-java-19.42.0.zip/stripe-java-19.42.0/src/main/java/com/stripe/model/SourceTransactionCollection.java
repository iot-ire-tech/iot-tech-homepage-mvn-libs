package com.stripe.model;

public class SourceTransactionCollection extends StripeCollection<SourceTransaction> {}
