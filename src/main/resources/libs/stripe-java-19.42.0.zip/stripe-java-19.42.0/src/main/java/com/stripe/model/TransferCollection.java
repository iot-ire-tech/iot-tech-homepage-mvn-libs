package com.stripe.model;

public class TransferCollection extends StripeCollection<Transfer> {}
