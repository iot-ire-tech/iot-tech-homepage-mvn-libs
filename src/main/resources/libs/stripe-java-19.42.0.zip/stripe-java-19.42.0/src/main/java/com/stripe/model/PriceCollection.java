package com.stripe.model;

public class PriceCollection extends StripeCollection<Price> {}
