package com.stripe.model;

public class BitcoinReceiverCollection extends StripeCollection<BitcoinReceiver> {}
