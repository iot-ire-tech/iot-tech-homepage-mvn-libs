package com.stripe.model;

public class IssuerFraudRecordCollection extends StripeCollection<IssuerFraudRecord> {}
