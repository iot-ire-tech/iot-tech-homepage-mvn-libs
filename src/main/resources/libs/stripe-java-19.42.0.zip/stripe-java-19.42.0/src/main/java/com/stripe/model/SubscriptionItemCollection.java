package com.stripe.model;

public class SubscriptionItemCollection extends StripeCollection<SubscriptionItem> {}
