package com.stripe.model;

public class SubscriptionScheduleCollection extends StripeCollection<SubscriptionSchedule> {}
