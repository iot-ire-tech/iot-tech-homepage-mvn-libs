package com.stripe.model;

public class CountrySpecCollection extends StripeCollection<CountrySpec> {}
