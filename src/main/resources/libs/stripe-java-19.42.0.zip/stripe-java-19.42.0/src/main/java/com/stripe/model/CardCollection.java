package com.stripe.model;

public class CardCollection extends StripeCollection<Card> {}
