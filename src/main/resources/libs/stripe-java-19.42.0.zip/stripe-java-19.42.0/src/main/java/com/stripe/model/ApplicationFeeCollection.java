package com.stripe.model;

public class ApplicationFeeCollection extends StripeCollection<ApplicationFee> {}
