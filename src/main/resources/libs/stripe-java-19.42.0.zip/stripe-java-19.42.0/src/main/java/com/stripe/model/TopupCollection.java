package com.stripe.model;

public class TopupCollection extends StripeCollection<Topup> {}
