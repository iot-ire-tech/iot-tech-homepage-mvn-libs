package com.stripe.model;

public class ProductCollection extends StripeCollection<Product> {}
