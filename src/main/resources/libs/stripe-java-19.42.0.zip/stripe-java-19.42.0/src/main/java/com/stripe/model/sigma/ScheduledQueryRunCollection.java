package com.stripe.model.sigma;

import com.stripe.model.StripeCollection;

public class ScheduledQueryRunCollection extends StripeCollection<ScheduledQueryRun> {}
