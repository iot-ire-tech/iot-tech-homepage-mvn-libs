package com.stripe.model;

public class PayoutCollection extends StripeCollection<Payout> {}
