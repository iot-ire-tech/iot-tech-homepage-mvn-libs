package com.stripe.model;

public class SkuCollection extends StripeCollection<Sku> {}
