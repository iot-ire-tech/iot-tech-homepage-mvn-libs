package com.stripe.model;

public class ReviewCollection extends StripeCollection<Review> {}
