package com.stripe.model;

public class UsageRecordSummaryCollection extends StripeCollection<UsageRecordSummary> {}
