package com.stripe.model;

public class DisputeCollection extends StripeCollection<Dispute> {}
