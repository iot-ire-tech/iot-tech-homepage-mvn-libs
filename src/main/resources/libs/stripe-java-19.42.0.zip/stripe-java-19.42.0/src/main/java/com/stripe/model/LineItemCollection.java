package com.stripe.model;

public class LineItemCollection extends StripeCollection<LineItem> {}
