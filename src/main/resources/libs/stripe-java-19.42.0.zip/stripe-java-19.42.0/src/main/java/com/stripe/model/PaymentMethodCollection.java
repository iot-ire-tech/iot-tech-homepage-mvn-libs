package com.stripe.model;

public class PaymentMethodCollection extends StripeCollection<PaymentMethod> {}
